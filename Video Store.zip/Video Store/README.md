# Video-Store (INTE-2512 final project)

- Git repository link: https://github.com/Nguyen-Bach/Video-Store/tree/main/Video%20Store
- UML diagram is in the doc directory


- Self reflection: I have worked on this project by myself due to unfortunate circumstances. By doing so, I have learned a lot more about Java and time management while coding. The project could definitely be optimized and further improve, but I definitely put a lot of effort into designing the UI and building the project from scratch by myself. How I would improve my codes would be by using methods a lot more, and trying to optimize if-else and while loops; the UI could also have been more intuitive for the user but considering the amount of effort and time that I put in, I personally think I did an excellence job by my own standard. I am going to give myself a (5).
