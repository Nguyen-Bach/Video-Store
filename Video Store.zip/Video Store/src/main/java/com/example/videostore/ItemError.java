package com.example.videostore;

public class ItemError extends Exception{
    public ItemError(String message) {super(message);}
}
